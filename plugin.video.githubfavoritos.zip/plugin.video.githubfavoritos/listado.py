import sys
import os



# Añadir la carpeta `resources/lib` al path de Python para que pueda encontrar las librerías necesarias
addon_path = os.path.dirname(__file__)
lib_path = os.path.join(addon_path, 'resources', 'lib')
sys.path.append(lib_path)

import json
import xbmc
import xbmcplugin
import xbmcgui
import xbmcvfs
import xbmcaddon
import requests

# Inicializar el addon y las rutas
ADDON = xbmcaddon.Addon()
addon_profile = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
if not xbmcvfs.exists(addon_profile):
    xbmcvfs.mkdirs(addon_profile)
favoritos_path = os.path.join(addon_profile, 'favoritos.json')
canales_path = os.path.join(addon_profile, 'canales.json')
eventos_path = os.path.join(addon_profile, 'eventos.json')
handle = int(sys.argv[1])
def descargar_archivos_de_github():
    """Descarga los archivos favoritos.json y canales.json desde GitHub."""
    for filename in ['favoritos.json', 'canales.json', 'eventos.json']:
        url = f'https://raw.githubusercontent.com/Thregarth/test/refs/heads/main/{filename}'
        try:
            response = requests.get(url)
            if response.status_code == 200:
                file_path = os.path.join(addon_profile, filename)
                with xbmcvfs.File(file_path, 'w') as f:
                    f.write(response.text)
                xbmc.log(f'Archivo {filename} descargado exitosamente desde GitHub', level=xbmc.LOGINFO)
            else:
                xbmc.log(f'Error al descargar {filename}: {response.status_code} - {response.text}', level=xbmc.LOGERROR)
        except requests.exceptions.RequestException as e:
            xbmc.log(f'Error en la solicitud HTTP: {str(e)}', level=xbmc.LOGERROR)

def listar_carpetas():
    """Lista las carpetas principales: Recomendados y Canales."""
    try:
        # Carpeta Recomendados
        list_item_recomendados = xbmcgui.ListItem(label='Recomendados')
        url_recomendados = f'{sys.argv[0]}?action=recomendados'
        xbmcplugin.addDirectoryItem(handle=handle, url=url_recomendados, listitem=list_item_recomendados, isFolder=True)

        # Carpeta Canales
        list_item_canales = xbmcgui.ListItem(label='Canales')
        url_canales = f'{sys.argv[0]}?action=canales'
        xbmcplugin.addDirectoryItem(handle=handle, url=url_canales, listitem=list_item_canales, isFolder=True)

        # Carpeta Eventos
        list_item_eventos = xbmcgui.ListItem(label='Eventos')
        url_eventos = f'{sys.argv[0]}?action=eventos'
        xbmcplugin.addDirectoryItem(handle=handle, url=url_eventos, listitem=list_item_eventos, isFolder=True)

        xbmcplugin.endOfDirectory(handle)
    except Exception as e:
        xbmc.log(f'Error al listar carpetas: {str(e)}', level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Error', 'No se pudieron listar las carpetas.', xbmcgui.NOTIFICATION_ERROR, 5000)

def listar_favoritos():
    """Lista los elementos en favoritos.json."""
    xbmcgui.Window(10025).setProperty("esRecomendados", "true")
    if not xbmcvfs.exists(favoritos_path):
        xbmcgui.Dialog().notification('Error', 'No se encontraron favoritos.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    # Leer favoritos.json
    with xbmcvfs.File(favoritos_path, 'r') as f:
        try:
            favoritos = json.load(f)
        except json.JSONDecodeError:
            xbmcgui.Dialog().notification('Error', 'No se pudo cargar favoritos.', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

    # Crear una entrada para cada favorito en el listado
    for item in favoritos:
        list_item = xbmcgui.ListItem(label=item['ListItem.Title'])
        list_item.setInfo('video', {
            'title': item['ListItem.Title'],
            'genre': item['ListItem.Genre'],
            'year': item['ListItem.Year'],
            'director': item['ListItem.Director'],
            'plot': item['ListItem.Plot'],
            'rating': item['ListItem.Rating'],
            'tagline': item['ListItem.Tagline'],

        })
        list_item.setArt({'icon': item['ListItem.Icon'], 'fanart': item['ListItem.Art(fanart)']})
        list_item.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle, item["ListItem.FilenameAndPath"], list_item, isFolder=True)

    xbmcplugin.endOfDirectory(handle)

def listar_canales():
    """Lista los elementos en canales.json."""
    if not xbmcvfs.exists(canales_path):
        xbmcgui.Dialog().notification('Error', 'No se encontraron canales.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    # Leer canales.json
    with xbmcvfs.File(canales_path, 'r') as f:
        try:
            canales = json.load(f)
        except json.JSONDecodeError:
            xbmcgui.Dialog().notification('Error', 'No se pudo cargar canales.', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

    # Crear una entrada para cada canal en el listado
    for item in canales:
        list_item = xbmcgui.ListItem(label=item['ListItem.Title'])
        list_item.setInfo('video', {
            'title': item['ListItem.Title'],
            'genre': item['ListItem.Genre'],
            'year': item['ListItem.Year'],
            'director': item['ListItem.Director'],
            'plot': item['ListItem.Plot'],
            'rating': item['ListItem.Rating'],
            'tagline': item['ListItem.Tagline'],
        })
        list_item.setArt({'icon': item['ListItem.Icon'], 'fanart': item['ListItem.Art(fanart)']})
        list_item.setProperty('IsPlayable', 'true')
        url = item["ListItem.FilenameAndPath"]
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

def listar_eventos():
    """Lista los elementos en eventos.json."""
    if not xbmcvfs.exists(eventos_path):
        xbmcgui.Dialog().notification('Error', 'No se encontraron eventos.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    # Leer eventos.json
    with xbmcvfs.File(eventos_path, 'r') as f:
        try:
            eventos = json.load(f)
        except json.JSONDecodeError:
            xbmcgui.Dialog().notification('Error', 'No se pudo cargar eventos.', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

    # Crear una entrada para cada canal en el listado
    for item in eventos:
        list_item = xbmcgui.ListItem(label=item['ListItem.Title'])
        list_item.setInfo('video', {
            'title': item['ListItem.Title'],
            'genre': item['ListItem.Genre'],
            'year': item['ListItem.Year'],
            'director': item['ListItem.Director'],
            'plot': item['ListItem.Plot'],
            'rating': item['ListItem.Rating'],
            'tagline': item['ListItem.Tagline'],
        })
        list_item.setArt({'icon': item['ListItem.Icon'], 'fanart': item['ListItem.Art(fanart)']})
        list_item.setProperty('IsPlayable', 'true')
        url = item["ListItem.FilenameAndPath"]
        xbmcplugin.addDirectoryItem(handle, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    xbmc.log(f'sys.argv: {sys.argv}', level=xbmc.LOGERROR)
    if len(sys.argv) > 2 and sys.argv[2]:
        params = dict(arg.split("=") for arg in sys.argv[2][1:].split("&") if len(arg.split("=")) == 2)
        action = params.get("action")
        path = params.get("path")

        if action == "recomendados":
            listar_favoritos()
        elif action == "canales":
            listar_canales()
        elif action == "eventos":
            listar_eventos()
    else:
        descargar_archivos_de_github()
        listar_carpetas()
