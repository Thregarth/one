from default import subir_a_github, favoritos_path

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json

def eliminar_favorito():
    title = xbmc.getInfoLabel('ListItem.Title')
    """Elimina un favorito por título y sincroniza con GitHub."""
    if not xbmcvfs.exists(favoritos_path):
        xbmcgui.Dialog().notification('Error', 'No se encontraron favoritos.', xbmcgui.NOTIFICATION_ERROR, 5000)
        return

    # Leer favoritos.json
    with xbmcvfs.File(favoritos_path, 'r') as f:
        try:
            favoritos = json.load(f)
        except json.JSONDecodeError:
            xbmcgui.Dialog().notification('Error', 'No se pudo cargar favoritos.', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

    # Filtrar el favorito a eliminar
    favoritos_filtrados = [item for item in favoritos if item['ListItem.OriginalTitle'] != title]

    # Guardar la nueva lista de favoritos
    with xbmcvfs.File(favoritos_path, 'w') as f:
        json.dump(favoritos_filtrados, f, indent=4)

    # Subir la nueva lista a GitHub
    subir_a_github(favoritos_path, 'favoritos')
    xbmcgui.Dialog().notification('Éxito', f'Favorito \"{title}\" eliminado y sincronizado en GitHub.', xbmcgui.NOTIFICATION_INFO, 5000)
    # Actualizar el listado en pantalla
    xbmc.executebuiltin("Container.Refresh")
if __name__ == '__main__':
    eliminar_favorito()
